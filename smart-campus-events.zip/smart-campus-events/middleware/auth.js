// middleware/auth.js — Session guards for admin + student

const requireAdmin = (req, res, next) => {
  if (req.session && req.session.admin) return next();
  return res.status(401).json({ success: false, message: 'Admin authentication required.' });
};

const requireStudent = (req, res, next) => {
  if (req.session && req.session.student) return next();
  return res.status(401).json({ success: false, message: 'Please log in to continue.', redirect: '/student-login.html' });
};

module.exports = { requireAdmin, requireStudent };
