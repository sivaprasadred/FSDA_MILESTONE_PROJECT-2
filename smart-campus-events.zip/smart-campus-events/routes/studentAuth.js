// routes/studentAuth.js — Student signup, login, logout, profile
const express = require('express');
const bcrypt  = require('bcryptjs');
const { body, validationResult } = require('express-validator');
const db      = require('../db');
const router  = express.Router();

// ─────────────────────────────
// POST /api/student/signup
// ─────────────────────────────
router.post(
  '/signup',
  [
    body('full_name').trim().notEmpty().withMessage('Full name is required.')
      .isLength({ min: 2, max: 150 }).withMessage('Name must be 2–150 characters.'),
    body('email').isEmail().normalizeEmail().withMessage('Valid email is required.'),
    body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters.'),
    body('student_id').trim().notEmpty().withMessage('Student ID is required.'),
    body('department').trim().notEmpty().withMessage('Department is required.'),
    body('year_of_study').isInt({ min: 1, max: 5 }).withMessage('Year of study must be 1–5.'),
    body('phone').matches(/^[6-9]\d{9}$/).withMessage('Enter a valid 10-digit mobile number.'),
  ],
  async (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const { full_name, email, password, student_id, department, year_of_study, phone } = req.body;

    try {
      // Check duplicate email
      const [[existingEmail]] = await db.query(
        'SELECT id FROM students WHERE email = ?', [email]
      );
      if (existingEmail) {
        return res.status(409).json({ success: false, message: 'This email is already registered. Please log in.' });
      }

      // Check duplicate student_id
      const [[existingId]] = await db.query(
        'SELECT id FROM students WHERE student_id = ?', [student_id]
      );
      if (existingId) {
        return res.status(409).json({ success: false, message: 'This Student ID is already registered.' });
      }

      const hashedPassword = await bcrypt.hash(password, 10);

      const [result] = await db.query(
        `INSERT INTO students (full_name, email, password, student_id, department, year_of_study, phone)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [full_name, email, hashedPassword, student_id, department, year_of_study, phone]
      );

      // Auto-login after signup
      req.session.student = {
        id:           result.insertId,
        full_name,
        email,
        student_id,
        department,
        year_of_study,
        phone,
      };

      return res.status(201).json({
        success: true,
        message: 'Account created successfully! Welcome to Campus Events.',
        student: req.session.student,
      });

    } catch (err) {
      next(err);
    }
  }
);

// ─────────────────────────────
// POST /api/student/login
// ─────────────────────────────
router.post(
  '/login',
  [
    body('email').isEmail().normalizeEmail().withMessage('Valid email is required.'),
    body('password').notEmpty().withMessage('Password is required.'),
  ],
  async (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const { email, password } = req.body;

    try {
      const [[student]] = await db.query(
        'SELECT * FROM students WHERE email = ?', [email]
      );

      if (!student) {
        return res.status(401).json({ success: false, message: 'No account found with this email.' });
      }

      const match = await bcrypt.compare(password, student.password);
      if (!match) {
        return res.status(401).json({ success: false, message: 'Incorrect password. Please try again.' });
      }

      req.session.student = {
        id:           student.id,
        full_name:    student.full_name,
        email:        student.email,
        student_id:   student.student_id,
        department:   student.department,
        year_of_study: student.year_of_study,
        phone:        student.phone,
      };

      return res.json({
        success: true,
        message: `Welcome back, ${student.full_name}!`,
        student: req.session.student,
      });

    } catch (err) {
      next(err);
    }
  }
);

// ─────────────────────────────
// POST /api/student/logout
// ─────────────────────────────
router.post('/logout', (req, res) => {
  const wasLoggedIn = !!req.session.student;
  delete req.session.student;
  if (!wasLoggedIn) {
    return res.json({ success: true, message: 'Not logged in.' });
  }
  res.json({ success: true, message: 'Logged out successfully.' });
});

// ─────────────────────────────
// GET /api/student/me
// ─────────────────────────────
router.get('/me', (req, res) => {
  if (req.session && req.session.student) {
    return res.json({ success: true, student: req.session.student });
  }
  return res.status(401).json({ success: false, message: 'Not logged in.' });
});

module.exports = router;
