// routes/registrations.js — Session-based registrations + admin view
const express = require('express');
const db      = require('../db');
const { requireStudent, requireAdmin } = require('../middleware/auth');
const router  = express.Router();

// POST /api/registrations — Register logged-in student
router.post('/', requireStudent, async (req, res, next) => {
  const { event_id }  = req.body;
  const studentDbId   = req.session.student.id;

  if (!event_id || isNaN(event_id)) {
    return res.status(400).json({ success: false, message: 'Valid event ID is required.' });
  }

  try {
    const [[event]] = await db.query(
      `SELECT e.*, COUNT(r.id) AS registered_count
       FROM events e
       LEFT JOIN registrations r ON r.event_id = e.id
       WHERE e.id = ? AND e.is_active = 1 AND e.event_date >= CURDATE()
       GROUP BY e.id`,
      [event_id]
    );

    if (!event) {
      return res.status(404).json({ success: false, message: 'Event not found or registration is closed.' });
    }
    if (event.registered_count >= event.max_seats) {
      return res.status(409).json({ success: false, message: 'This event is fully booked.' });
    }

    const [[existing]] = await db.query(
      'SELECT id FROM registrations WHERE event_id = ? AND student_db_id = ?',
      [event_id, studentDbId]
    );
    if (existing) {
      return res.status(409).json({ success: false, message: 'You are already registered for this event.' });
    }

    await db.query(
      'INSERT INTO registrations (event_id, student_db_id) VALUES (?, ?)',
      [event_id, studentDbId]
    );

    res.status(201).json({ success: true, message: `Successfully registered for "${event.title}"!` });
  } catch (err) {
    next(err);
  }
});

// GET /api/registrations/mine — Logged-in student's registrations
router.get('/mine', requireStudent, async (req, res, next) => {
  try {
    const [rows] = await db.query(
      `SELECT r.id, r.registered_at,
              e.id AS event_id, e.title, e.event_date, e.event_time,
              e.venue, e.department, e.event_type, e.speaker_name,
              f.rating    AS feedback_rating,
              f.comments  AS feedback_comments
       FROM registrations r
       JOIN events e ON e.id = r.event_id
       LEFT JOIN feedback f ON f.event_id = r.event_id AND f.student_db_id = r.student_db_id
       WHERE r.student_db_id = ?
       ORDER BY e.event_date DESC`,
      [req.session.student.id]
    );
    res.json({ success: true, data: rows });
  } catch (err) {
    next(err);
  }
});

// DELETE /api/registrations/:id — Cancel own registration
router.delete('/:id', requireStudent, async (req, res, next) => {
  try {
    const [result] = await db.query(
      'DELETE FROM registrations WHERE id = ? AND student_db_id = ?',
      [req.params.id, req.session.student.id]
    );
    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, message: 'Registration not found.' });
    }
    res.json({ success: true, message: 'Registration cancelled.' });
  } catch (err) {
    next(err);
  }
});

// GET /api/registrations/event/:eventId — Admin: all registrations for an event
router.get('/event/:eventId', requireAdmin, async (req, res, next) => {
  try {
    const [rows] = await db.query(
      `SELECT r.id, r.registered_at,
              s.full_name, s.email, s.student_id,
              s.department, s.year_of_study, s.phone,
              e.title AS event_title
       FROM registrations r
       JOIN students s ON s.id = r.student_db_id
       JOIN events   e ON e.id = r.event_id
       WHERE r.event_id = ?
       ORDER BY r.registered_at DESC`,
      [req.params.eventId]
    );
    res.json({ success: true, data: rows, count: rows.length });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
