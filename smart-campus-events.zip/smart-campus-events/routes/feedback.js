// routes/feedback.js — Session-based feedback submission + admin view
const express = require('express');
const { body, validationResult } = require('express-validator');
const db      = require('../db');
const { requireStudent, requireAdmin } = require('../middleware/auth');
const router  = express.Router();

// POST /api/feedback — Submit feedback (must be registered attendee, event must be past)
router.post(
  '/',
  requireStudent,
  [
    body('event_id').isInt({ min: 1 }).withMessage('Valid event ID required.'),
    body('rating').isInt({ min: 1, max: 5 }).withMessage('Rating must be 1–5.'),
    body('comments').optional().trim().isLength({ max: 1000 }),
  ],
  async (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const { event_id, rating, comments } = req.body;
    const studentDbId = req.session.student.id;

    try {
      // Must be registered
      const [[reg]] = await db.query(
        'SELECT id FROM registrations WHERE event_id = ? AND student_db_id = ?',
        [event_id, studentDbId]
      );
      if (!reg) {
        return res.status(403).json({ success: false, message: 'You must be a registered attendee to submit feedback.' });
      }

      // Event must be past
      const [[event]] = await db.query(
        'SELECT id, title FROM events WHERE id = ? AND event_date < CURDATE()',
        [event_id]
      );
      if (!event) {
        return res.status(400).json({ success: false, message: 'Feedback can only be submitted after the event has taken place.' });
      }

      await db.query(
        `INSERT INTO feedback (event_id, student_db_id, rating, comments)
         VALUES (?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE rating = VALUES(rating), comments = VALUES(comments)`,
        [event_id, studentDbId, rating, comments || null]
      );

      res.status(201).json({ success: true, message: 'Thank you for your feedback!' });
    } catch (err) {
      next(err);
    }
  }
);

// GET /api/feedback/event/:eventId — Public ratings for an event
router.get('/event/:eventId', async (req, res, next) => {
  try {
    const [rows] = await db.query(
      `SELECT f.rating, f.comments, f.submitted_at,
              CONCAT(LEFT(s.full_name,1),'***') AS student_name_masked
       FROM feedback f
       JOIN students s ON s.id = f.student_db_id
       WHERE f.event_id = ?
       ORDER BY f.submitted_at DESC`,
      [req.params.eventId]
    );
    const [[stats]] = await db.query(
      `SELECT ROUND(AVG(rating),1) AS avg_rating, COUNT(*) AS total_reviews,
              SUM(rating=5) AS r5, SUM(rating=4) AS r4, SUM(rating=3) AS r3,
              SUM(rating=2) AS r2, SUM(rating=1) AS r1
       FROM feedback WHERE event_id = ?`,
      [req.params.eventId]
    );
    res.json({ success: true, data: rows, stats });
  } catch (err) {
    next(err);
  }
});

// GET /api/feedback/admin/all — All feedback (admin)
router.get('/admin/all', requireAdmin, async (req, res, next) => {
  try {
    const [rows] = await db.query(
      `SELECT f.*, e.title AS event_title, s.full_name AS student_name
       FROM feedback f
       JOIN events   e ON e.id = f.event_id
       JOIN students s ON s.id = f.student_db_id
       ORDER BY f.submitted_at DESC
       LIMIT 200`
    );
    res.json({ success: true, data: rows });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
