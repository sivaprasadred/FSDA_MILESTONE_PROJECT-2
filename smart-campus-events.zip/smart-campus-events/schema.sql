-- ============================================================
-- Smart Campus Event Management System — Database Schema v2
-- Multi-user: Students sign up/login; Admin fixed password
-- ============================================================

CREATE DATABASE IF NOT EXISTS smart_campus_events;
USE smart_campus_events;

-- ─────────────────────────────────────────────
-- TABLE: admins
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS admins (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  username   VARCHAR(50)  NOT NULL UNIQUE,
  password   VARCHAR(255) NOT NULL,
  full_name  VARCHAR(100) NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ─────────────────────────────────────────────
-- TABLE: students  (NEW — authentication)
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS students (
  id             INT AUTO_INCREMENT PRIMARY KEY,
  full_name      VARCHAR(150) NOT NULL,
  email          VARCHAR(200) NOT NULL UNIQUE,
  password       VARCHAR(255) NOT NULL,
  student_id     VARCHAR(50)  NOT NULL UNIQUE,
  department     VARCHAR(100) NOT NULL,
  year_of_study  TINYINT      NOT NULL,
  phone          VARCHAR(15)  NOT NULL,
  created_at     DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ─────────────────────────────────────────────
-- TABLE: events
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS events (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  title         VARCHAR(200) NOT NULL,
  description   TEXT         NOT NULL,
  event_date    DATE         NOT NULL,
  event_time    TIME         NOT NULL,
  venue         VARCHAR(200) NOT NULL,
  department    VARCHAR(100) NOT NULL,
  event_type    ENUM('workshop','seminar','hackathon','cultural','sports','webinar','conference','other') NOT NULL,
  max_seats     INT          NOT NULL DEFAULT 100,
  image_url     VARCHAR(500) DEFAULT NULL,
  speaker_name  VARCHAR(150) DEFAULT NULL,
  speaker_bio   TEXT         DEFAULT NULL,
  is_active     TINYINT(1)   NOT NULL DEFAULT 1,
  created_by    INT,
  created_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at    DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (created_by) REFERENCES admins(id) ON DELETE SET NULL
);

-- ─────────────────────────────────────────────
-- TABLE: registrations
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS registrations (
  id             INT AUTO_INCREMENT PRIMARY KEY,
  event_id       INT          NOT NULL,
  student_db_id  INT          NOT NULL,
  registered_at  DATETIME     DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_event_student (event_id, student_db_id),
  FOREIGN KEY (event_id)      REFERENCES events(id)   ON DELETE CASCADE,
  FOREIGN KEY (student_db_id) REFERENCES students(id) ON DELETE CASCADE
);

-- ─────────────────────────────────────────────
-- TABLE: feedback
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS feedback (
  id             INT AUTO_INCREMENT PRIMARY KEY,
  event_id       INT         NOT NULL,
  student_db_id  INT         NOT NULL,
  rating         TINYINT     NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comments       TEXT        DEFAULT NULL,
  submitted_at   DATETIME    DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_feedback (event_id, student_db_id),
  FOREIGN KEY (event_id)      REFERENCES events(id)   ON DELETE CASCADE,
  FOREIGN KEY (student_db_id) REFERENCES students(id) ON DELETE CASCADE
);

-- ─────────────────────────────────────────────
-- SEED: Admin  (password = Admin@123)
-- ─────────────────────────────────────────────
INSERT INTO admins (username, password, full_name) VALUES
('admin',
 '$2a$10$U59Vch0ZWAgmd9Y/dp/zB.iWdLTEWLDwNj0vJ1AfnbG7y/fxir8VK',
 'Campus Administrator')
ON DUPLICATE KEY UPDATE username = username;

-- ─────────────────────────────────────────────
-- SEED: Demo Students  (password = Student@123)
-- ─────────────────────────────────────────────
INSERT INTO students (full_name, email, password, student_id, department, year_of_study, phone) VALUES
('Aditya Sharma',  'aditya@college.edu',  '$2a$10$zvfSpjzu7gPieF95kXzYSex4HKMltIBhBcE2r.U6MZqBVY7rPOJoS', 'CS2021001',  'Computer Science',       3, '9876543210'),
('Sneha Patel',    'sneha@college.edu',   '$2a$10$zvfSpjzu7gPieF95kXzYSex4HKMltIBhBcE2r.U6MZqBVY7rPOJoS', 'CS2021042',  'Computer Science',       3, '9876543211'),
('Rohan Verma',    'rohan@college.edu',   '$2a$10$zvfSpjzu7gPieF95kXzYSex4HKMltIBhBcE2r.U6MZqBVY7rPOJoS', 'IT2022015',  'Information Technology', 2, '9876543212'),
('Meera Nair',     'meera@college.edu',   '$2a$10$zvfSpjzu7gPieF95kXzYSex4HKMltIBhBcE2r.U6MZqBVY7rPOJoS', 'MBA2023001', 'Management',             1, '9876543213'),
('Karthik Iyer',   'karthik@college.edu', '$2a$10$zvfSpjzu7gPieF95kXzYSex4HKMltIBhBcE2r.U6MZqBVY7rPOJoS', 'MBA2022030', 'Management',             2, '9876543214')
ON DUPLICATE KEY UPDATE email = email;

-- ─────────────────────────────────────────────
-- SEED: Events
-- ─────────────────────────────────────────────
INSERT INTO events (title, description, event_date, event_time, venue, department, event_type, max_seats, speaker_name, speaker_bio) VALUES
('AI & Machine Learning Bootcamp',
 'A hands-on intensive workshop covering supervised learning, neural networks, and real-world AI applications using Python and TensorFlow. Participants will build and deploy their own ML models.',
 DATE_ADD(CURDATE(), INTERVAL 7 DAY),  '09:00:00', 'Seminar Hall A, Block-3',         'Computer Science',       'workshop',   80, 'Dr. Priya Raghavan',   'Senior ML Engineer at Google India with 12 years of experience in deep learning.'),
('Entrepreneurship & Startup Financing Seminar',
 'Learn how to pitch your startup idea to investors, structure your business plan, and understand term sheets. Live Q&A with successful founders.',
 DATE_ADD(CURDATE(), INTERVAL 10 DAY), '14:00:00', 'Auditorium, Main Block',           'Management',             'seminar',   200, 'Mr. Arjun Mehta',      'Co-founder of FinPath Technologies; Forbes 30 Under 30 India 2022.'),
('National-Level Hackathon: CodeStorm 2024',
 '36-hour hackathon challenging teams to solve real-world problems in healthcare, agriculture, and fintech. Over ₹1,50,000 in prizes across categories.',
 DATE_ADD(CURDATE(), INTERVAL 14 DAY), '08:00:00', 'Innovation Lab, Block-5',          'Computer Science',       'hackathon', 150, NULL, NULL),
('Cloud Architecture & DevOps Workshop',
 'Practical workshop on AWS and Azure covering Docker, Kubernetes, CI/CD pipelines, and infrastructure-as-code with live demos.',
 DATE_ADD(CURDATE(), INTERVAL 5 DAY),  '10:00:00', 'Computer Lab 2, Block-1',          'Information Technology', 'workshop',   50, 'Ms. Kavitha Sundaram', 'DevOps Architect at Infosys Ltd. Certified AWS Solutions Architect and CKA.'),
('Annual Cultural Fest — Tarang 2024',
 'Three days of music, dance, drama, and art competitions celebrating the diverse cultures of India. Inter-college teams welcome.',
 DATE_ADD(CURDATE(), INTERVAL 21 DAY), '17:00:00', 'Open Air Theatre, Campus Ground',  'Cultural Committee',     'cultural',  500, NULL, NULL),
('Cybersecurity & Ethical Hacking Seminar',
 'Modern threat landscapes, penetration testing methodologies, and career pathways in cybersecurity with a live demo of common vulnerabilities.',
 DATE_ADD(CURDATE(), INTERVAL 12 DAY), '11:00:00', 'Seminar Hall B, Block-3',          'Information Technology', 'seminar',   100, 'Mr. Rahul Krishnan',   'Lead Security Analyst at Wipro CyberShield. CEH and OSCP certified.'),
('Research Paper Writing & Publication Workshop',
 'Guidance on structuring a research paper, selecting IEEE/Springer journals, avoiding plagiarism, and peer-review simulation.',
 DATE_ADD(CURDATE(), INTERVAL 3 DAY),  '09:30:00', 'Library Conference Room',          'Research & Development', 'workshop',   40, 'Dr. Sathish Kumar',    'Associate Professor & Research Coordinator, 60+ Scopus-indexed papers.'),
('Inter-Department Sports Meet',
 'Annual sporting event featuring cricket, football, volleyball, badminton, chess, and athletics. Represent your department and win the Sports Shield!',
 DATE_ADD(CURDATE(), INTERVAL 30 DAY), '07:00:00', 'Sports Complex, Ground Floor',     'Physical Education',     'sports',    300, NULL, NULL);

-- ─────────────────────────────────────────────
-- SEED: Sample Registrations
-- ─────────────────────────────────────────────
INSERT INTO registrations (event_id, student_db_id) VALUES
(1,1),(1,2),(1,3),(2,4),(2,5),(3,1),(4,3),(5,2),(7,1),(7,2)
ON DUPLICATE KEY UPDATE event_id = event_id;

-- ─────────────────────────────────────────────
-- SEED: Sample Feedback
-- ─────────────────────────────────────────────
INSERT INTO feedback (event_id, student_db_id, rating, comments) VALUES
(7, 1, 5, 'Absolutely brilliant! Dr. Sathish explained every step clearly.'),
(7, 2, 4, 'Very informative. Would have liked more time for hands-on exercises.')
ON DUPLICATE KEY UPDATE rating = rating;
