// main.js — Student portal with auth
'use strict';

let currentPage      = 1;
let currentEventId   = null;
let currentStudent   = null;

// ── Boot ──────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  await checkAuth();
  loadMeta();
  loadEvents(1);
  loadHeroStats();

  document.getElementById('filter-search').addEventListener('input',
    debounce(() => loadEvents(1), 450)
  );
});

// ── Auth check → build navbar ─────────────────────────────────
async function checkAuth() {
  try {
    const { data } = await apiFetch('/api/student/me');
    if (data.success) {
      currentStudent = data.student;
      renderLoggedInNav();
    } else {
      renderGuestNav();
    }
  } catch {
    renderGuestNav();
  }
}

function renderLoggedInNav() {
  const initials = currentStudent.full_name.split(' ').map(w => w[0]).join('').slice(0,2).toUpperCase();
  document.getElementById('nav-myevents').style.display = 'block';
  document.getElementById('nav-right').innerHTML = `
    <a href="/my-events.html" class="btn btn-ghost btn-sm">
      <i class="fa fa-ticket"></i> My Events
    </a>
    <div style="position:relative" id="user-menu-wrap">
      <button onclick="toggleUserMenu()" style="display:flex;align-items:center;gap:8px;background:rgba(200,145,42,.15);border:1px solid rgba(200,145,42,.3);border-radius:var(--radius-sm);padding:6px 12px;cursor:pointer;color:var(--gold-light);font-family:var(--font-body);font-size:.85rem;font-weight:500">
        <span style="width:28px;height:28px;background:var(--gold);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:.75rem;font-weight:700;color:var(--forest)">${initials}</span>
        ${currentStudent.full_name.split(' ')[0]}
        <i class="fa fa-chevron-down" style="font-size:.7rem;opacity:.7"></i>
      </button>
      <div id="user-dropdown" style="display:none;position:absolute;top:calc(100% + 8px);right:0;background:#fff;border:1px solid var(--border);border-radius:var(--radius);box-shadow:var(--shadow-lg);min-width:200px;z-index:200">
        <div style="padding:14px 16px;border-bottom:1px solid var(--border)">
          <div style="font-weight:600;font-size:.875rem;color:var(--text-primary)">${escHtml(currentStudent.full_name)}</div>
          <div style="font-size:.78rem;color:var(--text-muted);margin-top:2px">${escHtml(currentStudent.student_id)} · ${escHtml(currentStudent.department)}</div>
        </div>
        <a href="/my-events.html" style="display:flex;align-items:center;gap:10px;padding:10px 16px;font-size:.85rem;color:var(--text-secondary);transition:.15s" onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''">
          <i class="fa fa-ticket" style="width:14px;color:var(--forest-light)"></i> My Registrations
        </a>
        <button onclick="logout()" style="width:100%;display:flex;align-items:center;gap:10px;padding:10px 16px;font-size:.85rem;color:var(--error);background:none;border:none;cursor:pointer;font-family:var(--font-body);border-top:1px solid var(--border)" onmouseover="this.style.background='#fde8e8'" onmouseout="this.style.background=''">
          <i class="fa fa-right-from-bracket" style="width:14px"></i> Sign Out
        </button>
      </div>
    </div>`;

  // Update hero CTA
  document.getElementById('hero-login-btn').outerHTML = `
    <a href="/my-events.html" class="btn btn-outline btn-lg">
      <i class="fa fa-ticket"></i> My Registrations
    </a>`;
}

function renderGuestNav() {
  document.getElementById('nav-right').innerHTML = `
    <a href="/student-login.html" class="btn btn-ghost btn-sm">
      <i class="fa fa-sign-in-alt"></i> Sign In
    </a>
    <a href="/student-signup.html" class="btn btn-primary btn-sm">
      <i class="fa fa-user-plus"></i> Create Account
    </a>`;
}

function toggleUserMenu() {
  const dd = document.getElementById('user-dropdown');
  dd.style.display = dd.style.display === 'none' ? 'block' : 'none';
}

// Close dropdown on outside click
document.addEventListener('click', (e) => {
  if (!document.getElementById('user-menu-wrap')?.contains(e.target)) {
    const dd = document.getElementById('user-dropdown');
    if (dd) dd.style.display = 'none';
  }
});

async function logout() {
  await apiFetch('/api/student/logout', { method: 'POST' });
  window.location.reload();
}

// ── Hero Stats ────────────────────────────────────────────────
async function loadHeroStats() {
  try {
    const { data } = await apiFetch('/api/events?limit=1&upcoming=true');
    if (data.success) animateNumber('stat-events', data.pagination.total);
    const { data: m } = await apiFetch('/api/events/meta');
    if (m.success)    animateNumber('stat-depts', m.departments.length);
    document.getElementById('stat-students').textContent = '200+';
  } catch {}
}

function animateNumber(id, target) {
  const el = document.getElementById(id);
  if (!el || !target) return;
  let cur = 0;
  const step = Math.ceil(target / 30);
  const t = setInterval(() => {
    cur = Math.min(cur + step, target);
    el.textContent = cur;
    if (cur >= target) clearInterval(t);
  }, 40);
}

// ── Filter Meta ───────────────────────────────────────────────
async function loadMeta() {
  try {
    const { data } = await apiFetch('/api/events/meta');
    if (!data.success) return;
    const sel = document.getElementById('filter-dept');
    data.departments.forEach(dept => {
      const o = document.createElement('option');
      o.value = dept; o.textContent = dept;
      sel.appendChild(o);
    });
  } catch {}
}

// ── Load Events ───────────────────────────────────────────────
async function loadEvents(page = 1) {
  currentPage = page;
  const grid = document.getElementById('events-grid');
  grid.innerHTML = Array(6).fill(`
    <div class="skeleton-card">
      <div class="skeleton" style="height:8px;margin-bottom:18px"></div>
      <div class="skeleton" style="height:18px;width:60%;margin-bottom:10px"></div>
      <div class="skeleton" style="height:14px;width:90%;margin-bottom:5px"></div>
      <div class="skeleton" style="height:14px;width:75%;margin-bottom:20px"></div>
      <div class="skeleton" style="height:80px;margin-bottom:16px;border-radius:8px"></div>
      <div class="skeleton" style="height:36px"></div>
    </div>`).join('');

  const params = new URLSearchParams({ page, limit: 9, upcoming: 'true' });
  const search = document.getElementById('filter-search').value.trim();
  const type   = document.getElementById('filter-type').value;
  const dept   = document.getElementById('filter-dept').value;
  const date   = document.getElementById('filter-date').value;
  if (search) params.set('search', search);
  if (type)   params.set('type', type);
  if (dept)   params.set('department', dept);
  if (date)   params.set('date', date);

  try {
    const { data } = await apiFetch(`/api/events?${params}`);
    if (!data.success) { grid.innerHTML = errorCard(); return; }

    const { data: events, pagination } = data;
    document.getElementById('results-count').textContent =
      pagination.total === 0 ? 'No events match your filters.'
        : `Showing ${events.length} of ${pagination.total} event${pagination.total !== 1 ? 's' : ''}`;

    grid.innerHTML = events.length ? events.map(renderEventCard).join('') : `
      <div class="empty-state" style="grid-column:1/-1">
        <div class="empty-state-icon">🔍</div>
        <h3>No events found</h3>
        <p>Try adjusting your filters or search term.</p>
        <button class="btn btn-ghost mt-24" onclick="clearFilters()">Clear Filters</button>
      </div>`;

    renderPagination(pagination);
  } catch {
    grid.innerHTML = errorCard();
  }
}

function errorCard() {
  return `<div class="empty-state" style="grid-column:1/-1">
    <div class="empty-state-icon">⚠️</div>
    <h3>Failed to load events</h3>
    <p>Check your connection and try again.</p>
    <button class="btn btn-forest mt-24" onclick="loadEvents(1)">Retry</button>
  </div>`;
}

// ── Render Event Card ─────────────────────────────────────────
function renderEventCard(ev) {
  const pct       = Math.round((ev.registered_count / ev.max_seats) * 100);
  const fillClass = seatFillClass(pct);
  const isFull    = pct >= 100;
  const color     = typeColor(ev.event_type);

  // Register button logic
  let btnHtml;
  if (isFull) {
    btnHtml = `<button class="btn btn-sm" disabled style="opacity:.5;cursor:not-allowed;padding:7px 14px;border-radius:6px;background:var(--bg-alt);color:var(--text-muted);border:1.5px solid var(--border);margin-left:12px;flex-shrink:0">Full</button>`;
  } else if (!currentStudent) {
    btnHtml = `<a href="/student-login.html?from=/" class="btn btn-ghost btn-sm" style="margin-left:12px;flex-shrink:0">
      <i class="fa fa-sign-in-alt"></i> Login
    </a>`;
  } else {
    btnHtml = `<button class="btn btn-primary btn-sm" style="margin-left:12px;flex-shrink:0"
      onclick="openRegistrationModal(${ev.id})">
      <i class="fa fa-plus"></i> Register
    </button>`;
  }

  return `
  <div class="event-card type-${ev.event_type}">
    <div class="event-card-banner"></div>
    <div class="event-card-body">
      <div class="event-card-meta">
        <span class="badge" style="background:${color}22;color:${color};text-transform:capitalize">${ev.event_type}</span>
        <span class="badge badge-dept">${escHtml(ev.department)}</span>
        ${!isFull && ev.seats_available <= 10
          ? `<span class="badge badge-warning">${ev.seats_available} seats left</span>` : ''}
        ${isFull ? '<span class="badge badge-full">Fully Booked</span>' : ''}
      </div>
      <div class="event-card-title">${escHtml(ev.title)}</div>
      <div class="event-card-desc">${escHtml(ev.description)}</div>
      <div class="event-card-details">
        <div class="event-detail-row"><span class="event-detail-icon">📅</span><span>${formatDate(ev.event_date)}</span></div>
        <div class="event-detail-row"><span class="event-detail-icon">🕐</span><span>${formatTime(ev.event_time)}</span></div>
        <div class="event-detail-row"><span class="event-detail-icon">📍</span><span>${escHtml(ev.venue)}</span></div>
        ${ev.speaker_name ? `<div class="event-detail-row"><span class="event-detail-icon">🎤</span><span>${escHtml(ev.speaker_name)}</span></div>` : ''}
      </div>
      <div class="event-card-footer">
        <div class="seats-bar-wrap">
          <div class="seats-label">
            <span>${ev.registered_count} registered</span>
            <span>${isFull ? 'Full' : ev.seats_available + ' available'}</span>
          </div>
          <div class="seats-bar">
            <div class="seats-bar-fill ${fillClass}" style="width:${Math.min(pct,100)}%"></div>
          </div>
        </div>
        ${btnHtml}
      </div>
    </div>
  </div>`;
}

function escHtml(str) {
  return String(str ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');
}

// ── Pagination ────────────────────────────────────────────────
function renderPagination({ page, totalPages }) {
  const c = document.getElementById('pagination');
  if (totalPages <= 1) { c.innerHTML = ''; return; }
  let html = `<button class="page-btn" onclick="loadEvents(${page-1})" ${page<=1?'disabled':''}>‹</button>`;
  for (let i = 1; i <= totalPages; i++) {
    if (totalPages > 7 && i > 2 && i < totalPages-1 && Math.abs(i-page) > 1) {
      if (i === 3 || i === totalPages-2) html += `<span style="padding:0 4px;color:var(--text-muted)">…</span>`;
      continue;
    }
    html += `<button class="page-btn ${i===page?'active':''}" onclick="loadEvents(${i})">${i}</button>`;
  }
  html += `<button class="page-btn" onclick="loadEvents(${page+1})" ${page>=totalPages?'disabled':''}>›</button>`;
  c.innerHTML = html;
}

function clearFilters() {
  ['filter-search','filter-type','filter-dept','filter-date'].forEach(id => {
    document.getElementById(id).value = '';
  });
  loadEvents(1);
}

// ── Registration Modal ────────────────────────────────────────
async function openRegistrationModal(eventId) {
  if (!currentStudent) {
    window.location.href = '/student-login.html?from=/';
    return;
  }
  currentEventId = eventId;
  try {
    const { data } = await apiFetch(`/api/events/${eventId}`);
    if (!data.success) { showToast('Event not found.','error'); return; }
    const ev = data.data;

    document.getElementById('modal-event-info').innerHTML = `
      <div style="font-family:var(--font-head);font-size:1rem;font-weight:700;margin-bottom:6px">${escHtml(ev.title)}</div>
      <div style="display:flex;gap:16px;flex-wrap:wrap;font-size:.82rem;color:var(--text-secondary)">
        <span>📅 ${formatDate(ev.event_date)}</span>
        <span>🕐 ${formatTime(ev.event_time)}</span>
        <span>📍 ${escHtml(ev.venue)}</span>
        <span>💺 ${ev.seats_available} seats left</span>
      </div>`;

    document.getElementById('prev-name').textContent  = currentStudent.full_name;
    document.getElementById('prev-id').textContent    = currentStudent.student_id;
    document.getElementById('prev-email').textContent = currentStudent.email;
    document.getElementById('prev-dept').textContent  = `${currentStudent.department} — Year ${currentStudent.year_of_study}`;

    openModal('reg-modal');
  } catch {
    showToast('Failed to load event.','error');
  }
}

function closeModal() { closeModalById('reg-modal'); }

async function submitRegistration() {
  const btn = document.getElementById('reg-submit-btn');
  btn.disabled = true;
  btn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Registering…';

  try {
    const { data } = await apiFetch('/api/registrations', {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ event_id: currentEventId }),
    });

    if (data.success) {
      closeModal();
      showToast(data.message, 'success', 5000);
      loadEvents(currentPage);
    } else {
      showToast(data.message || 'Registration failed.', 'error');
    }
  } catch {
    showToast('Registration failed. Please try again.', 'error');
  } finally {
    btn.disabled = false;
    btn.innerHTML = '<i class="fa fa-check"></i> Confirm Registration';
  }
}
