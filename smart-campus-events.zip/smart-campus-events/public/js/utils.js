// utils.js — Shared utility functions

// ── Toast Notifications ───────────────────────────────────────
const ICONS = { success: '✅', error: '❌', warning: '⚠️', info: 'ℹ️' };

function showToast(message, type = 'success', duration = 4000) {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `
    <span class="toast-icon">${ICONS[type] || ICONS.info}</span>
    <span class="toast-message">${message}</span>
    <button class="toast-dismiss" onclick="this.parentElement.remove()">✕</button>
  `;
  container.appendChild(toast);
  setTimeout(() => toast.remove(), duration);
}

// ── Date / Time Formatting ────────────────────────────────────
function formatDate(dateStr) {
  const d = new Date(dateStr + 'T00:00:00');
  return d.toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
}

function formatTime(timeStr) {
  if (!timeStr) return '';
  const [h, m] = timeStr.split(':');
  const hour   = parseInt(h);
  const ampm   = hour >= 12 ? 'PM' : 'AM';
  const hr12   = hour % 12 || 12;
  return `${hr12}:${m} ${ampm}`;
}

function formatDateTime(dateStr, timeStr) {
  return `${formatDate(dateStr)} at ${formatTime(timeStr)}`;
}

function isDatePast(dateStr) {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const d = new Date(dateStr + 'T00:00:00');
  return d < today;
}

function getMonthAbbr(dateStr) {
  const d = new Date(dateStr + 'T00:00:00');
  return d.toLocaleString('en-IN', { month: 'short' }).toUpperCase();
}

function getDay(dateStr) {
  return new Date(dateStr + 'T00:00:00').getDate();
}

// ── Type → Color Map ─────────────────────────────────────────
const TYPE_COLORS = {
  workshop:   '#1a5f8a',
  seminar:    '#6c3483',
  hackathon:  '#c0392b',
  cultural:   '#e67e22',
  sports:     '#27ae60',
  webinar:    '#16a085',
  conference: '#2980b9',
  other:      '#5a5246',
};

function typeColor(type) {
  return TYPE_COLORS[type] || '#5a5246';
}

// ── Seat fill colour ─────────────────────────────────────────
function seatFillClass(pct) {
  if (pct >= 100) return 'full';
  if (pct >= 80)  return 'warning';
  return '';
}

// ── API helpers ───────────────────────────────────────────────
async function apiFetch(url, options = {}) {
  const res  = await fetch(url, { credentials: 'include', ...options });
  const data = await res.json();
  return { res, data };
}

// ── Debounce ──────────────────────────────────────────────────
function debounce(fn, delay = 400) {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delay);
  };
}

// ── Modal helpers ─────────────────────────────────────────────
function openModal(id) {
  const m = document.getElementById(id);
  if (m) { m.classList.add('open'); document.body.style.overflow = 'hidden'; }
}

function closeModalById(id) {
  const m = document.getElementById(id);
  if (m) { m.classList.remove('open'); document.body.style.overflow = ''; }
}

// Close on backdrop click
document.addEventListener('click', (e) => {
  if (e.target.classList.contains('modal-backdrop')) {
    e.target.classList.remove('open');
    document.body.style.overflow = '';
  }
});

// Close on Escape
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    document.querySelectorAll('.modal-backdrop.open').forEach(m => {
      m.classList.remove('open');
      document.body.style.overflow = '';
    });
  }
});
