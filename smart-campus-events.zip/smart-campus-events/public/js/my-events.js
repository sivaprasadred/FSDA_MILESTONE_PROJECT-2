// my-events.js — Student dashboard: session-based, no email lookup
'use strict';

let allRegistrations = [];
let feedbackRating   = 0;
let currentStudent   = null;

// ── Boot ──────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  await checkStudentAuth();
  buildNav();
  loadMyRegistrations();
});

async function checkStudentAuth() {
  try {
    const { data } = await apiFetch('/api/student/me');
    if (data.success) {
      currentStudent = data.student;
    } else {
      // Redirect to login
      window.location.href = '/student-login.html?from=/my-events.html';
    }
  } catch {
    window.location.href = '/student-login.html?from=/my-events.html';
  }
}

function buildNav() {
  if (!currentStudent) return;
  const initials = currentStudent.full_name.split(' ').map(w => w[0]).join('').slice(0,2).toUpperCase();
  document.getElementById('nav-right').innerHTML = `
    <span style="color:rgba(247,243,236,.7);font-size:.85rem;margin-right:8px">${escHtml(currentStudent.full_name)}</span>
    <button onclick="logout()" class="btn btn-outline btn-sm"><i class="fa fa-sign-out-alt"></i> Sign Out</button>`;

  document.getElementById('student-welcome').textContent =
    `${currentStudent.student_id}  ·  ${currentStudent.department}  ·  Year ${currentStudent.year_of_study}`;
}

async function logout() {
  await apiFetch('/api/student/logout', { method: 'POST' });
  window.location.href = '/student-login.html';
}

// ── Load Registrations ────────────────────────────────────────
async function loadMyRegistrations() {
  try {
    const { data } = await apiFetch('/api/registrations/mine');
    document.getElementById('loading-state').style.display = 'none';

    if (!data.success) { showError(); return; }

    allRegistrations = data.data;

    if (!allRegistrations.length) {
      document.getElementById('my-events-empty').classList.remove('hidden');
      return;
    }

    const today    = new Date(); today.setHours(0,0,0,0);
    const upcoming = allRegistrations.filter(r => new Date(r.event_date + 'T00:00:00') >= today);
    const past     = allRegistrations.filter(r => new Date(r.event_date + 'T00:00:00') <  today);

    document.getElementById('tab-upcoming-count').textContent = upcoming.length;
    document.getElementById('tab-past-count').textContent     = past.length;
    document.getElementById('my-events-count').textContent    =
      `${allRegistrations.length} event${allRegistrations.length !== 1 ? 's' : ''} registered`;

    document.getElementById('my-events-results').style.display = 'block';
    renderTab('upcoming', upcoming);
    renderTab('past', past);

  } catch {
    document.getElementById('loading-state').style.display = 'none';
    showError();
  }
}

function showError() {
  document.getElementById('my-events-empty').classList.remove('hidden');
  document.getElementById('my-events-empty').innerHTML = `
    <div class="empty-state">
      <div class="empty-state-icon">⚠️</div>
      <h3>Failed to load registrations</h3>
      <p>Please refresh the page and try again.</p>
      <button class="btn btn-forest mt-24" onclick="location.reload()">Refresh</button>
    </div>`;
}

// ── Tab switch ────────────────────────────────────────────────
function switchTab(tab) {
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.querySelector(`[data-tab="${tab}"]`).classList.add('active');
  document.getElementById('tab-upcoming').classList.toggle('hidden', tab !== 'upcoming');
  document.getElementById('tab-past').classList.toggle('hidden',     tab !== 'past');
}

function renderTab(tab, items) {
  const listId = tab === 'upcoming' ? 'upcoming-list' : 'past-list';
  const isPast = tab === 'past';
  document.getElementById(listId).innerHTML = items.length
    ? items.map(r => renderRegCard(r, isPast)).join('')
    : emptyTab(isPast ? 'No past events found.' : 'No upcoming events registered.');
}

function emptyTab(msg) {
  return `<div class="empty-state" style="padding:40px 24px">
    <div class="empty-state-icon">📭</div>
    <h3>${msg}</h3>
    <a href="/" class="btn btn-ghost mt-24">Browse Events</a>
  </div>`;
}

// ── Render Registration Card ──────────────────────────────────
function renderRegCard(reg, isPast) {
  const color     = typeColor(reg.event_type);
  const hasFeedback = reg.feedback_rating;

  return `
  <div class="reg-event-card">
    <div class="reg-event-date" style="background:${color}">
      <div class="reg-event-date-day">${getDay(reg.event_date)}</div>
      <div class="reg-event-date-mon">${getMonthAbbr(reg.event_date)}</div>
    </div>
    <div class="reg-event-info">
      <div class="reg-event-title">${escHtml(reg.title)}</div>
      <div class="reg-event-sub">
        <span>🕐 ${formatTime(reg.event_time)}</span>
        <span>📍 ${escHtml(reg.venue)}</span>
        <span>🏢 ${escHtml(reg.department)}</span>
      </div>
      ${reg.speaker_name ? `<div style="font-size:.8rem;color:var(--text-muted);margin-top:4px">🎤 ${escHtml(reg.speaker_name)}</div>` : ''}
      <div style="margin-top:8px">
        <span class="badge" style="background:${color}20;color:${color};text-transform:capitalize;font-size:.7rem">${reg.event_type}</span>
      </div>
    </div>
    <div style="display:flex;flex-direction:column;align-items:flex-end;gap:8px;flex-shrink:0">
      ${isPast
        ? hasFeedback
          ? `<div style="text-align:center">
               <div style="color:var(--gold);font-size:1.1rem;letter-spacing:2px">${'★'.repeat(reg.feedback_rating)}${'☆'.repeat(5-reg.feedback_rating)}</div>
               <div style="font-size:.72rem;color:var(--text-muted);margin-top:2px">Your rating</div>
             </div>`
          : `<button class="btn btn-primary btn-sm" onclick="openFeedbackModal(${reg.event_id}, '${escHtml(reg.title).replace(/'/g,"\\'")}')">
               <i class="fa fa-star"></i> Rate Event
             </button>`
        : `<div style="text-align:center">
             <div style="font-size:.7rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:.4px">Reg. ID</div>
             <div style="font-weight:700;color:var(--forest);font-size:.9rem">#${reg.id}</div>
           </div>`
      }
    </div>
  </div>`;
}

function escHtml(str) {
  return String(str ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');
}

// ── Feedback ──────────────────────────────────────────────────
function openFeedbackModal(eventId, eventTitle) {
  feedbackRating = 0;
  document.getElementById('fb-event-id').value = eventId;
  document.getElementById('feedback-event-name').textContent = eventTitle;
  document.getElementById('fb-comments').value = '';
  document.getElementById('err-rating').classList.add('hidden');
  setRating(0);
  openModal('feedback-modal');
}

function closeFeedbackModal() { closeModalById('feedback-modal'); }

function setRating(val) {
  feedbackRating = val;
  document.querySelectorAll('#star-rating .star').forEach((s, i) => {
    s.classList.toggle('filled', i < val);
  });
}

async function submitFeedback() {
  if (!feedbackRating) {
    document.getElementById('err-rating').classList.remove('hidden');
    return;
  }

  try {
    const { data } = await apiFetch('/api/feedback', {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({
        event_id: parseInt(document.getElementById('fb-event-id').value),
        rating:   feedbackRating,
        comments: document.getElementById('fb-comments').value.trim(),
      }),
    });

    if (data.success) {
      showToast('Feedback submitted! Thank you.', 'success');
      closeFeedbackModal();
      loadMyRegistrations();
    } else {
      showToast(data.message || 'Failed to submit.', 'error');
    }
  } catch {
    showToast('Failed to submit feedback.', 'error');
  }
}
