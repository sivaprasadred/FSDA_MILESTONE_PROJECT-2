// server.js — Smart Campus Event Management System v2
require('dotenv').config();
const express        = require('express');
const session        = require('express-session');
const cors           = require('cors');
const path           = require('path');

const authRoutes        = require('./routes/auth');
const studentAuthRoutes = require('./routes/studentAuth');
const eventRoutes       = require('./routes/events');
const regRoutes         = require('./routes/registrations');
const feedbackRoutes    = require('./routes/feedback');
const { errorHandler, notFound } = require('./middleware/errorHandler');

const app  = express();
const PORT = process.env.PORT || 3000;

// ─── Middleware ────────────────────────────────────────────────
app.use(cors({ origin: true, credentials: true }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(session({
  secret:            process.env.SESSION_SECRET || 'campus_secret_2024',
  resave:            false,
  saveUninitialized: false,
  cookie: {
    secure:   false,
    httpOnly: true,
    maxAge:   8 * 60 * 60 * 1000,   // 8 hours
  },
}));

// ─── Static files ──────────────────────────────────────────────
app.use(express.static(path.join(__dirname, 'public')));

// ─── API Routes ────────────────────────────────────────────────
app.use('/api/auth',          authRoutes);
app.use('/api/student',       studentAuthRoutes);
app.use('/api/events',        eventRoutes);
app.use('/api/registrations', regRoutes);
app.use('/api/feedback',      feedbackRoutes);

// ─── Catch-all ─────────────────────────────────────────────────
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.use(notFound);
app.use(errorHandler);

// ─── Start ─────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n🚀  Smart Campus Events  →  http://localhost:${PORT}`);
  console.log(`📋  Student login       →  http://localhost:${PORT}/student-login.html`);
  console.log(`🔐  Admin dashboard     →  http://localhost:${PORT}/admin/dashboard.html`);
  console.log(`    Admin credentials   →  admin / Admin@123`);
  console.log(`    Demo student        →  aditya@college.edu / Student@123\n`);
});

module.exports = app;
